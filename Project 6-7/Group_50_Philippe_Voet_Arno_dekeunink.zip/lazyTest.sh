#python Test.py -f -t sort.txt -c FD_Group50.circ
#python Test.py -f -t fibonacci.txt -c FD_Group50.circ
python Test.py -f -t TestBEQ.txt -c FD_Group50.circ
python Test.py -f -t TestBLT.txt -c FD_Group50.circ
python Test.py -f -t TestJAL.txt -c FD_Group50.circ
python Test.py -f -t TestADDI.txt -c FD_Group50.circ
python Test.py -s -i SDTest_Group50.txt -c FD_Group50.circ
